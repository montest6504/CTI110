print('Enter x: ')
x = int(input())


print('x doubled is:', (2 * x))